// DOM elements
const statusEl = document.getElementById('status');
const statusIcon = document.getElementById('statusIcon');
const checkIcon = document.getElementById('checkIcon');
const kickedIcon = document.getElementById('kickedIcon');
const statusTitle = document.getElementById('statusTitle');
const statusMessage = document.getElementById('statusMessage');
const joinForm = document.getElementById('joinForm');
const roomIdInput = document.getElementById('roomId');
const studentNameInput = document.getElementById('studentName');
const joinBtn = document.getElementById('joinBtn');
const leaveBtn = document.getElementById('leaveBtn');
const dismissKickedBtn = document.getElementById('dismissKickedBtn');
const errorEl = document.getElementById('error');
const joiningLoadingEl = document.getElementById('joiningLoading');
const waitingLoadingEl = document.getElementById('waitingLoading');
const cancelBtn = document.getElementById('cancelBtn');

// Load Supabase
const SUPABASE_URL = 'https://hduyofdbpspjcuwvackd.supabase.co';
const SUPABASE_KEY = 'sb_publishable_zI1zwUpMhbnU1cMwRJBTug_or6athhK';

// Initialize extension
const SupabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// Check current status
checkStatus();

// Listen for status updates from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'statusUpdate') {
    if (request.joined) {
      showJoinedState();
    } else {
      showJoinForm();
    }
  } else if (request.action === 'kicked') {
    showKickedState();
  }
  return true;
});

// Event listeners
joinBtn.addEventListener('click', handleJoin);
cancelBtn.addEventListener('click', handleCancel);
leaveBtn.addEventListener('click', handleLeave);
dismissKickedBtn.addEventListener('click', handleDismissKicked);

// Check current extension status
function checkStatus() {
  console.log('Checking extension status...');
  chrome.storage.local.get(['roomId', 'studentId', 'wasKicked'], (result) => {
    console.log('Storage result:', result);
    if (result.wasKicked) {
      console.log('User was kicked, showing kicked state');
      showKickedState();
    } else if (result.roomId && result.studentId) {
      console.log('User is joined, showing joined state');
      showJoinedState();
    } else {
      console.log('User is not joined, showing join form');
      showJoinForm();
    }
  });
}

// Periodically check status (in case background script misses storage changes)
setInterval(checkStatus, 2000);

// Show join form
function showJoinForm() {
  statusEl.classList.remove('active', 'kicked');
  joinForm.classList.remove('hidden');
  joinBtn.style.display = 'block';
  leaveBtn.style.display = 'none';
  hideError();
}

// Show joined state
function showJoinedState() {
  statusEl.classList.remove('kicked');
  statusEl.classList.add('active');
  checkIcon.style.display = 'block';
  kickedIcon.style.display = 'none';
  statusTitle.textContent = "You're in!";
  statusMessage.textContent = 'Your browser is being managed by your teacher';
  leaveBtn.style.display = 'block';
  joinForm.classList.add('hidden');
}

// Show kicked state
function showKickedState() {
  statusEl.classList.add('active', 'kicked');
  checkIcon.style.display = 'none';
  kickedIcon.style.display = 'block';
  statusTitle.textContent = 'You were removed';
  statusMessage.textContent = 'Your teacher removed you from the room';
  leaveBtn.style.display = 'none';
  dismissKickedBtn.style.display = 'block';
  joinForm.classList.add('hidden');
  roomIdInput.value = '';
  studentNameInput.value = '';
}

// Handle dismiss kicked notification
function handleDismissKicked() {
  chrome.storage.local.set({ wasKicked: false }, () => {
    showJoinForm();
  });
}

// Show loading state
function showLoading() {
  joiningLoadingEl.classList.add('show');
  joinForm.classList.add('hidden');
}

// Show waiting state
function showWaiting() {
  waitingLoadingEl.classList.add('show');
  joinForm.classList.add('hidden');
}

// Hide loading state
function hideLoading() {
  joiningLoadingEl.classList.remove('show');
  waitingLoadingEl.classList.remove('show');
}

// Show error
function showError(message) {
  errorEl.textContent = message;
  errorEl.classList.add('show');
}

// Hide error
function hideError() {
  errorEl.classList.remove('show');
}

// Handle join room
async function handleJoin() {
  const roomId = roomIdInput.value.trim();
  const studentName = studentNameInput.value.trim();

  if (!roomId || !studentName) {
    showError('Please enter both room ID and your name');
    return;
  }

  // Validate room code is exactly 6 digits
  if (!/^\d{6}$/.test(roomId)) {
    showError('Room code must be exactly 6 digits');
    return;
  }

  hideError();
  showWaiting();

  // Get extension ID
  const extensionId = chrome.runtime.id;

  // Open join.html on classcastle.org with room code, student name, and extension ID
  const joinUrl = `https://classcastle.org/join.html?code=${encodeURIComponent(roomId)}&name=${encodeURIComponent(studentName)}&from_extension=true&extension_id=${encodeURIComponent(extensionId)}`;

  // Create a new tab instead of updating the existing one
  chrome.tabs.create({ url: joinUrl }, (tab) => {
    console.log('Opened join.html in tab:', tab.id);
    // Don't close popup, keep it open with loading state
  });
}

// Handle cancel
function handleCancel() {
  hideLoading();
  showJoinForm();
}

// Handle leave room
function handleLeave() {
  function resetForm() {
    showJoinForm();
    roomIdInput.value = '';
    studentNameInput.value = '';
  }

  // Leave room via background script.
  // Using a callback (not a Promise chain) here, since chrome.runtime.sendMessage
  // returns undefined -- not a Promise -- whenever a callback is supplied.
  // Errors are surfaced via chrome.runtime.lastError, not a rejected promise.
  chrome.runtime.sendMessage({ action: 'leaveRoom' }, () => {
    if (chrome.runtime.lastError) {
      console.log('Failed to send leave message:', chrome.runtime.lastError.message);
      // Fallback: clear storage directly
      chrome.storage.local.remove(['roomId', 'studentId'], resetForm);
      return;
    }
    resetForm();
  });
}